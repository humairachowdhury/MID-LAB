<?php

	session_start();
	$con = mysqli_connect("localhost","root","","wt");
	if(isset($_SESSION["name"]))
	{
		$sql = "select * from emran where id='$_SESSION[name]' ";
			
			$query = mysqli_query($con,$sql);
			
			while($arr = mysqli_fetch_assoc($query))
				{
					
?>





<center>
	<table border="1" cellpadding="5" cellspacing="0">
		<tr><td colspan="2" align="CENTER">Profile</td></tr>
		<tr><td>ID</td><td><?php echo $arr['id']; ?></tr>
		<tr><td>NAME</td><td><?php echo $arr['name']; ?></td></tr>	
		<tr><td>USER TYPE</td><td><?php echo$arr['type']; ?></td></tr>
		<tr><td colspan="2" align="right"><a href="user_home.php">Go Home</a></td></tr>
	</table>			
</center>

<?php 
				}
	
		}
		else
		{
			header("Location:login.php");
		}
		
				
			
?>